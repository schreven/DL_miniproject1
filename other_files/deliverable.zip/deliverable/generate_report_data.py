


import Sweeps
import Visualizations as Vis

Sweeps.sweep_first()

Sweeps.sweep_second()

Vis.plot_first()

Vis.plot_second()